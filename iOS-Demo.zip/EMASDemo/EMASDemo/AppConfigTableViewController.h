//
//  AppConfigTableViewController.h
//  EMASDemo
//
//  Created by zhishui.lcq on 2018/4/8.
//  Copyright © 2018年 zhishui.lcq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppConfigTableViewController : UITableViewController

@end
