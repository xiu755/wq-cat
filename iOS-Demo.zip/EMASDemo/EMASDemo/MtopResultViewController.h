//
//  MtopResultViewController.h
//  EMASDemo
//
//  Created by jiangpan on 2018/5/2.
//  Copyright © 2018年 zhishui.lcq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MtopResultViewController : UIViewController

- (instancetype)initWithRequestData:(NSDictionary *)requestData;

@end
