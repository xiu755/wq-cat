//
//  ViewController.h
//  EMASMANTestApp
//
//  Created by junmo on 2018/6/13.
//  Copyright © 2018年 junmo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MANViewController : UIViewController


@end

