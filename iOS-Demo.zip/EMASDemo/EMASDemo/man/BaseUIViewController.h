//
//  BaseUIViewController.h
//  EMASMANTestApp
//
//  Created by junmo on 2018/6/15.
//  Copyright © 2018年 junmo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseUIViewController : UIViewController

@end
