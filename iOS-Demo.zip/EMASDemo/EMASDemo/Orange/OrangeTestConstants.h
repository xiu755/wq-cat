//
//  OrangeTestConstants.h
//  test
//
//  Created by jiangpan on 2018/5/21.
//  Copyright © 2018年 jiangpan. All rights reserved.
//

#ifndef OrangeTestConstants_h
#define OrangeTestConstants_h

#define FirstFeatureKey1    @"feature_enable"
#define FirstFeatureKey2    @"feature_url"
#define FirstFeatureName    @"feature"


#define SecondFeatureKey1    @"theme_name"
#define SecondFeatureKey2    @"theme_color"
#define SecondFeatureName    @"theme"


#endif /* OrangeTestConstants_h */
