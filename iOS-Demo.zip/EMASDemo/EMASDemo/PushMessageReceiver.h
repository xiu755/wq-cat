//
//  PushMessageReceiver.h
//  EMASDemo
//
//  Created by wuchen.xj on 2018/11/15.
//  Copyright © 2018年 EMAS. All rights reserved.
//

#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN

@interface PushMessageReceiver : NSObject

@end

NS_ASSUME_NONNULL_END
