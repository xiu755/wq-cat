//
//  EMASWXRenderViewController.h
//  EMASDemo
//
//  Created by daoche.jb on 2018/6/28.
//  Copyright © 2018年 EMAS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <EMASWeex/EMASWXViewController.h>

//自定义渲染容器
@interface EMASWXRenderViewController : EMASWXViewController

@end
