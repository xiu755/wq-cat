//
//  ExEMASWXSDKEngine.h
//  EMASDemo
//
//  Created by daoche.jb on 2018/6/28.
//  Copyright © 2018年 EMAS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <EMASWeex/EMASWXSDKEngine.h>

@interface EMASWXSubSDKEngine : EMASWXSDKEngine

+ (void)setup;

@end
