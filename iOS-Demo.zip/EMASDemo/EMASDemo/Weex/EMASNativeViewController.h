//
//  EMASNativeViewController.h
//  EMASWeexDemo
//
//  Created by daoche.jb on 2018/8/20.
//  Copyright © 2018年 EMAS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EMASHostViewController.h"

@interface EMASNativeViewController : EMASHostViewController

@end
