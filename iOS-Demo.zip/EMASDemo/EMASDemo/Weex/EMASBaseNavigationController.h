//
//  EMASBaseNavigationController.h
//  EMASWeexDemo
//
//  Created by daoche.jb on 2018/7/27.
//  Copyright © 2018年 EMAS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EMASBaseNavigationController : UINavigationController

@end
