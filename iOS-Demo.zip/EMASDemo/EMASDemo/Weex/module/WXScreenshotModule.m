//
//  WXScreenshotModule.m
//  EmasWeexComponents
//
//  Created by  cijian on 19/03/2018.
//

#import "WXScreenshotModule.h"

@implementation WXScreenshotModule

@end


