//
//  WXScreenshotModule.h
//  EmasWeexComponents
//
//  Created by  cijian on 19/03/2018.
//

#import <Foundation/Foundation.h>

@interface WXScreenshotModule : NSObject 

@end
