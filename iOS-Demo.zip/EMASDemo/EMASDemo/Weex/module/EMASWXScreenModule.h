//
//  WXScreenModule.h
//  Pods
//
//  Created by 齐山 on 17/4/28.
//
//

#import <Foundation/Foundation.h>
#import <WeexSDK/WXModuleProtocol.h>

@interface EMASWXScreenModule : NSObject <WXModuleProtocol>

@end
