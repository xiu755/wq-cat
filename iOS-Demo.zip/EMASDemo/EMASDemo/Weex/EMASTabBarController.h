//
//  EMASTabBarController.h
//  EMASWeexDemo
//
//  Created by daoche.jb on 2018/7/27.
//  Copyright © 2018年 EMAS. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CYLTabBarController/CYLTabBarController.h>

@interface EMASTabBarController : CYLTabBarController

@end
