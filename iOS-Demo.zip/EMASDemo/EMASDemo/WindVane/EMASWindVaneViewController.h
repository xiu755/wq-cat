//
//  EMASWindVaneViewController.h
//  EMASDemo
//
//  Created by daoche.jb on 2018/9/29.
//  Copyright © 2018年 EMAS. All rights reserved.
//

#import <WindVane/WindVane.h>

NS_ASSUME_NONNULL_BEGIN

@interface EMASWindVaneViewController : WVUIWebViewController

@end

NS_ASSUME_NONNULL_END
