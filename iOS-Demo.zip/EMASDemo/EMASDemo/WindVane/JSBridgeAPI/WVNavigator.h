//
//  WVNavigation.h
//  Demo
//
//  Created by daoche.jb on 2018/9/26.
//  Copyright © 2018年 WindVane. All rights reserved.
//

#import <WindVaneBridge/WindVaneBridge.h>

@interface WVNavigator : WVDynamicHandler

@end

