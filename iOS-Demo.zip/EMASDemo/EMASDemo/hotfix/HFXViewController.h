//
//  ViewController.h
//  AlicloudHotFixTestApp
//
//  Created by EMAS on 2017/9/12.
//  Copyright © 2017年 EMAS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HFXViewController : UIViewController


@end

