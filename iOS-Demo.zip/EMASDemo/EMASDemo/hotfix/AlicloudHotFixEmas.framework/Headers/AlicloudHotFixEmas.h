//
//  AlicloudHotFix.h
//  AlicloudHotFix
//
//  Created by junmo on 2017/9/12.
//  Copyright © 2017年 junmo. All rights reserved.
//

#define HOTFIX_IOS_SDK_VERSION  @"1.0.6"

#import <AlicloudHotFixEmas/AlicloudHotFixServiceEmas.h>
