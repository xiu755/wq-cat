interface{"HFXTestClass"}
function output(self)
return ('[HFXTestClass] This is replaced output.')
end
