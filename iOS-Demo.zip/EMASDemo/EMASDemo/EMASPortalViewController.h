//
//  EMASPortalViewController.h
//  EMASDemo
//
//  Created by daoche.jb on 2018/11/8.
//  Copyright © 2018 EMAS. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface EMASPortalViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIButton *nativeButton;
@property (weak, nonatomic) IBOutlet UIButton *weexButton;
@property (weak, nonatomic) IBOutlet UIButton *H5Button;

@end

NS_ASSUME_NONNULL_END
