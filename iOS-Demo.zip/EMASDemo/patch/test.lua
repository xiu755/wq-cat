interface{"TestClass"}
function output(self)
return ('[TestClass] This is replaced output. by chantu')
end
