interface{"HFXTestClass"}
function output(self)
return ('[TestClass] This is replaced output. chantu test again')
end
