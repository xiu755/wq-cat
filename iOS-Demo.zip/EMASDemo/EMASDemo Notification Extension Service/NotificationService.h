//
//  NotificationService.h
//  notificationservice
//
//  Created by wuchen.xj on 2018/7/26.
//  Copyright © 2018年 Taobao.com. All rights reserved.
//

#import <UserNotifications/UserNotifications.h>

@interface NotificationService : UNNotificationServiceExtension

@end
