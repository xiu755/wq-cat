package com.taobao.demo.agoo;

import org.android.agoo.mezu.MeizuPushReceiver;

/**
 * Created by jason on 17/11/15.
 */

public class TaoMeizuPushReceiver extends MeizuPushReceiver {
}
