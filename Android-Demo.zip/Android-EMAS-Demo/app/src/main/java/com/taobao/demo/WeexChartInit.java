package com.taobao.demo;

import android.content.Context;

public class WeexChartInit {
    public static void init(Context context) {
    }
}
