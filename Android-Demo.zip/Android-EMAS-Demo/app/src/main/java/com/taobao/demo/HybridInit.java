package com.taobao.demo;

import android.app.Application;


/**
 * created by chenluan.cht@alibaba-inc.com
 * at 2018/11/5
 */
public class HybridInit {
    public static void init(Application application) {
    }
}
