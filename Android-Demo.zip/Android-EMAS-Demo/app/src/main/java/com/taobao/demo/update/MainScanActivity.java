package com.taobao.demo.update;

import android.os.Bundle;

import com.journeyapps.barcodescanner.CaptureActivity;

/**
 * Created by liyazhou on 2017/12/25.
 */

public class MainScanActivity extends CaptureActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
