package com.taobao.demo;

public class BindingXInit {
    public static void init() {
    }
}
